# User Story Template

**Title**: [Feature Name]

**As a** [Persona],  
**I want** [Goal],  
**So that** [Benefit].

## Acceptance Criteria
- [Criterion 1]
- [Criterion 2]
