# ⚪ Azure DevOps Task — Base Template (Golden Repo Standard)

---

## 🏷️ Title
> Provide a short, descriptive title for the task.

---

## 🔢 Task ID
`[TASK-XXXX]`  
> (Auto-generated in Azure DevOps — placeholder for reference)

---

## 👤 Task Owner / Assignee
> Name of the person responsible for completing the task.

---

## 🎯 Objective
> Explain the purpose of the task and how it contributes to the parent User Story or Feature.

---

## 🧩 Description / Details
> Provide clear instructions, steps, or technical details needed to complete the task.

---

## ✅ Acceptance Criteria / Definition of Done
> Define measurable conditions for task completion.

- [ ] Step or action 1  
- [ ] Step or action 2  
- [ ] Step or action 3  

---

## 📄 Deliverables
> List outputs or artifacts expected from this task.

- [ ] Deliverable 1  
- [ ] Deliverable 2  

---

## 📦 Scope

**In Scope:**
- [Specify what this task covers]

**Out of Scope:**
- [Specify what is excluded]

---

## ⚠️ Dependencies / Risks

**Dependencies:**
- [Link parent User Story, Feature, or other tasks]

**Risks:**
- [Potential blockers or issues]

---

## 👥 Stakeholders
> List people involved or impacted by this task.

| Role | Name | Responsibility |
|------|------|----------------|
| Owner / Assignee |  | Execute task |
| Reviewer / QA |  | Verify completion |
| Other |  |  |

---

## 🕒 Estimation
> Provide estimated effort or duration.

| Metric | Value |
|--------|-------|
| Hours / Days | X |
| Priority | High / Medium / Low |

---

## 🔗 Linked Work Items

**Parent User Story / PBI:**  
- `[US-XXXX]`  

**Related Tasks:**  
- `[TASK-XXXX]`  

**Related Bugs:**  
- `[BUG-XXXX]`  

---

## 📝 Notes / References
> Include supporting documentation, scripts, or links.

- [Document or Link]  

---

> **Template Location:**  
> `/.ado/templates/task-base-template.md`  
> **Maintained by:** [Team or Department Name]  
> **Last Updated:** YYYY-MM-DD
