# 🟣 Azure DevOps Epic — Base Template (Golden Repo Standard)

---

## 🏷️ Title
> Provide a concise, outcome-driven title that clearly summarizes the Epic.

---

## 🔢 Epic ID
`[EPIC-XXXX]`  
> (Auto-generated in Azure DevOps — placeholder for reference)

---

## 🎯 Business Goal / Objective
> Describe the strategic objective, business driver, or desired outcome this Epic supports.

---

## 🧩 Problem Statement
> Explain the problem, gap, or opportunity this Epic addresses.

---

## 💡 Proposed Solution / Approach
> Summarize the high-level concept, approach, or proposed solution to achieve the objective.

---

## 📦 Scope

**In Scope:**
- [List what's included in the Epic]

**Out of Scope:**
- [List what's excluded or deferred to other Epics]

---

## 📊 Success Metrics / KPIs

| Metric | Target | Measurement Method |
|--------|---------|---------------------|
| Example Metric | Target Value | How you'll measure it |

---

## ✅ Acceptance Criteria
> Define the conditions that must be met for this Epic to be considered complete.

- [ ] Criterion 1  
- [ ] Criterion 2  
- [ ] Criterion 3  

---

## 📄 Deliverables
> List tangible outputs, documents, or assets expected from this Epic.

- [ ] Deliverable 1  
- [ ] Deliverable 2  

---

## ⚠️ Dependencies / Risks

**Dependencies:**
- [List related Epics, Features, or external dependencies]

**Risks:**
- [Identify key risks or potential blockers]

---

## 👥 Stakeholders

| Role | Name | Responsibility |
|------|------|----------------|
| Product Owner |  |  |
| Technical Lead |  |  |
| QA Lead |  |  |
| DevOps Engineer |  |  |
| Other |  |  |

---

## 🕒 Timeline / Milestones

| Milestone | Target Date | Status |
|------------|--------------|--------|
| Planning Complete | YYYY-MM-DD | ☐ |
| Development Start | YYYY-MM-DD | ☐ |
| Testing Complete | YYYY-MM-DD | ☐ |
| Go-Live | YYYY-MM-DD | ☐ |

---

## 🔗 Linked Work Items

**Features:**
- `[FEAT-XXXX]`

**User Stories:**
- `[US-XXXX]`

**Tasks:**
- `[TASK-XXXX]`

**Bugs:**
- `[BUG-XXXX]`

---

## 📝 Notes / References
> Add any supporting links, documentation, or reference materials.

- [Document Name](URL)
- [Reference Link](URL)

---

> **Template Location:**  
> `/.ado/templates/epic-base-template.md`  
> **Maintained by:** [Team or Department Name]  
> **Last Updated:** YYYY-MM-DD
