# Risk Assessment Form

| Risk ID | Description         | Impact Level | Mitigation Strategy       |
|---------|---------------------|--------------|---------------------------|
| R001    | Data breach risk    | High         | Implement encryption      |
| R002    | Model bias          | Medium       | Add fairness validation   |
