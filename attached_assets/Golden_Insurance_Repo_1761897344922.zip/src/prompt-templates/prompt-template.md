# AI Prompt Template

**Context**: [Project/Domain]  
**Task**: [Specific Goal]  
**Constraints**: [Rules/Compliance]  
**Expected Output**: [Format/Structure]
